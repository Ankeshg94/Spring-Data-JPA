package com.dailycodebuffer.spring.data.jpa.tutorial.repository;

import com.dailycodebuffer.spring.data.jpa.tutorial.entity.Guardian;
import com.dailycodebuffer.spring.data.jpa.tutorial.entity.Student;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class StudentRepositoryTest {

    @Autowired
    private StudentRepository studentRepository;

    @Test
    public void saveStudent() {

        Student stu = Student.builder()
                .firstName("Ankesh")
                .lastName("gupta")
                .emailId("ankesh@gmail.com")
//                        .guardianEmail("ashokKumar@gmail.com")
//                        .guardianMobile("8764328953")
                .build();
        studentRepository.save(stu);
    }

    @Test
    public void saveWithGuardian() {
        Guardian guardian = Guardian.builder()
                .name("XYZ")
                .email("xyz@mail.com")
                .mobile("9785346651")
                .build();

        Student stu = Student.builder()
                .firstName("Nitesh")
                .lastName("gupta")
                .emailId("nitesh@gmail.com")
                .guardian(guardian)
                .build();

        studentRepository.save(stu);
    }

    @Test
    public void printAllStudent() {
        List<Student> list = studentRepository.findAll();
        System.out.println(list);

    }

    @Test
    public void testFindByName() {

        List<Student> studens = studentRepository.findByFirstName("Ankesh");

        System.out.println(studens);
    }

    @Test
    public void testFindStudentByEmailAddress() {
        Student stu = studentRepository.findStudentByEmailAddress("Ankesh@gmail.com");
        System.out.println(stu);
    }

    @Test
    public void testFindFirstNameByEmailAddress() {
        String s = studentRepository.findFirstNameByEmailAddress("Ankesh@gmail.com");
        System.out.println(s);
    }


    @Test
    public void testGetStudentByEmailAddressWithNamedParam(){
        Student s =  studentRepository.getStudentByEmailAddressWithNamedParam("Ankesh@gmail.com");
        System.out.println(s);
    }


    @Test
    public void testUpdateStudentNameByEmailAddress(){

        studentRepository.updateStudentNameByEmailAddress("AnkeshG", "Ankesh@gmail.com");
    }

}