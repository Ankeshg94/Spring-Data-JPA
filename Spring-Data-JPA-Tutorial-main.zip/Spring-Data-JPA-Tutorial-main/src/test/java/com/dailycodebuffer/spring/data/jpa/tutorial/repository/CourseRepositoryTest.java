package com.dailycodebuffer.spring.data.jpa.tutorial.repository;

import com.dailycodebuffer.spring.data.jpa.tutorial.entity.Course;
import com.dailycodebuffer.spring.data.jpa.tutorial.entity.CourseMaterial;
import com.dailycodebuffer.spring.data.jpa.tutorial.entity.Student;
import com.dailycodebuffer.spring.data.jpa.tutorial.entity.Teacher;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class CourseRepositoryTest {

    @Autowired
    CourseRepository courseRepository;

    @Test
    public void printCourse(){

        List<Course> course = courseRepository.findAll();

        System.out.println(course);
    }

    @Test
    public void testSaveCourseWithTeacher(){

        Teacher teacher  =Teacher.builder()
                            .firstName("Anoop")
                            .lastName("Shekhawat")
                            .build();

        Course course = Course.builder()
                        .credit(9)
                        .title("Angular")
                        .teacher(teacher)
                        .build();

        courseRepository.save(course);
    }

    @Test
    public void testPagination(){

        Pageable firstPageWithThreeRecords = PageRequest.of(0,3, Sort.by("title").descending());
        Pageable secondPageWithThreeRecords = PageRequest.of(1,2);

        int total = courseRepository
                .findAll(firstPageWithThreeRecords)
                .getTotalPages();

       List<Course> courses =  courseRepository
               .findAll(firstPageWithThreeRecords)
               .getContent();

        System.out.println("total pages" + total);
        System.out.println(courses);
    }

    @Test

    public void testSaveCourseWithStudentAndTeacher(){

        Teacher teacher  =Teacher.builder()
                .firstName("XYZ")
                .lastName("Xyz")
                .build();

        Student student = Student.builder()
                            .firstName("Abhishek")
                            .emailId("sinngh@gmail.com")
                            .lastName("singh")
                            .build();

        List<Student> students = new ArrayList<Student>();
        students.add(student);
        Course course = Course.builder()
                        .title("AI")
                        .credit(12)
                        .teacher(teacher)
                        .students(students)
                        .build();

        courseRepository.save(course);
    }
}