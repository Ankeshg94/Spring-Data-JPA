package com.dailycodebuffer.spring.data.jpa.tutorial.repository;

import com.dailycodebuffer.spring.data.jpa.tutorial.entity.Course;
import com.dailycodebuffer.spring.data.jpa.tutorial.entity.Teacher;
import com.sun.tools.javac.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class TeacherRepositoryTest {

    @Autowired
    TeacherRepository teacherRepository ;

    @Test
    public void saveTeacher(){

        Course course = Course.builder()
                        .title("JAVA")
                        .credit(5)
                        .build();
        Course course1 = Course.builder()
                .title("DBA")
                .credit(9)
                .build();

        Course course2 = Course.builder()
                .title("Python")
                .credit(10)
                .build();

        Teacher teacher =  Teacher.builder()
                            .firstName("Pathak")
                            .lastName("sir")
//                            .courses(List.of(course, course1, course2))
                            .build();

        teacherRepository.save(teacher);
    }
}