package com.dailycodebuffer.spring.data.jpa.tutorial.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
//Data annotation is from lombok which adds getter/setters/equals & HashCode methos
@Data
//Builder annotation from lombok implements builder pattern for our class
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(
        name = "tbl_student",
        uniqueConstraints = @UniqueConstraint(
                name = "unique_mailId_",       //constraintName
                columnNames = "email_address"
        )
)
public class Student {
    @Id
    @SequenceGenerator(
            name= "student_sequence",
            sequenceName = "student_sequence",
            allocationSize = 1
    )
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "student_sequence"
    )
    private long studentId;
    private String firstName;
    private String lastName;
    //@NotNull is located inside thhe Javax package and this annnotationn is performed in the validation cycle
    // hence it is triggered before database query is triggered. that's why it is recommended
    //but for now we are using hibernate's way of doing it as below .
    @Column(
            name = "email_address",
            nullable = false
    )
    private String emailId;

    private Guardian guardian;
}
