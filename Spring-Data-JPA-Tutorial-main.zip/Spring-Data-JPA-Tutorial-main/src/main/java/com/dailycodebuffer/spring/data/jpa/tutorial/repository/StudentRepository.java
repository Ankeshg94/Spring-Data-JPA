package com.dailycodebuffer.spring.data.jpa.tutorial.repository;

import com.dailycodebuffer.spring.data.jpa.tutorial.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import javax.transaction.Transactional;
import java.util.List;

public interface StudentRepository extends JpaRepository<Student, Long> {

     List<Student> findByFirstName(String firstName);

     //JPQL
     //remember -> Query syntax is  on java object
     @Query("select s from Student s where s.emailId = ?1 ")
     Student findStudentByEmailAddress(String emailId);

     @Query("select s.firstName from Student s where s.emailId = ?1 ")
     String findFirstNameByEmailAddress(String emailId);

     //SQL Native query
     @Query(
             value = "select *  from tbl_student where email_address = ?1",
             nativeQuery = true
     )
     Student getStudentByEmailAddressNative(String emailAddress);

     //Query with Named parameter

     @Query(
             value = "select *  from tbl_student where email_address = :emailId",
             nativeQuery = true
     )
     Student getStudentByEmailAddressWithNamedParam(
             @Param("emailId") String emailAddress
     );


     //need to add @Transactional for update/delete operations otherwise it will throw error - org.springframework.dao.InvalidDataAccessApiUsageException: Executing an update/delete query; nested exception is javax.persistence.TransactionRequiredException: Executing an update/delete query
     @Transactional
     @Modifying   //for write operations we need to add this annotation
     @Query(
             value = "update tbl_student set first_name = :name where email_address = :emailId",
             nativeQuery = true
     )
     int updateStudentNameByEmailAddress(
             @Param("name") String nanme,
             @Param("emailId") String emailId
     );

}
